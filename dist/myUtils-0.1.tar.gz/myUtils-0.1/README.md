# myUtils
My simple Python utilities